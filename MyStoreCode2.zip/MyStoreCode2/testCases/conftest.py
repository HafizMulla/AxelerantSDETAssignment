""" This file contain the fixture for launching the browser """
from selenium import webdriver
import pytest

@pytest.fixture()
def setup():
    """
    This set up launch the Chrome browser

    :return: The webdriver of the browser launched
    """
    driver=webdriver.Chrome(executable_path="..\\Resources\\chromedriver.exe")
    return driver
