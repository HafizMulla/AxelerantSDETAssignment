""" This file contains all the test cases to run """

from pageObjects.NavigateToPages import NavigateToTabs
from pageObjects.NewsLetterPage import NewsLetterPage


class Test_Assessment():

    baseURL="http://automationpractice.com/index.php"
    email_id="abc123@gmail.com"
    newsletter_success_alert_msg="You have successfully subscribed to this newsletter."
    newsletter_failure_alert_msg="This email address is already registered."
    title_error_message = "Title is not matching"
    header_error_message = "Header is not matching"
    footer_error_message = "Footer is not matching"


    def test_click_women_tshirts(self, setup):
        """ Test to validate by clicking Tshirts sub-tab under Women tab by verify the header (
        searchbox), footer (newsletterbox) and page title.

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        errors = []

        # Opening the Chrome browser
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(10)

        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_women_tshirts(self.driver)
        if act_title != "T-shirts - My Store":
            errors.append(self.title_error_message)
        if not self.np.verify_header_present():
            errors.append(self.header_error_message)
        if not self.np.verify_header_present():
            errors.append(self.footer_error_message)
        self.driver.close()

        assert not errors, "errors occured:{}".format("\n".join(errors))

    def test_click_women_blouses(self, setup):
        """ Test to validate by clicking Blouses sub-tab under Women tab to verify the header (
        searchbox), footer (newsletterbox) and page title.

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        errors = []
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(10)
        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_women_blouses(self.driver)
        if act_title != "Blouses - My Store":
            errors.append(self.title_error_message)
        if not self.np.verify_header_present():
            errors.append(self.header_error_message)
        if not self.np.verify_footer_present():
            errors.append(self.footer_error_message)
        self.driver.close()

        assert not errors, "errors occured:{}".format("\n".join(errors))

    def test_click_women_casual_dresses(self, setup):
        """ Test to validate by clicking Casual Dresses sub-tab under Women tab to verify the
        header (searchbox), footer (newsletterbox) and page title.

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        errors=[]
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(10)
        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_women_casual_dresses(self.driver)
        if act_title != "Casual Dresses - My Store":
            errors.append(self.title_error_message)
        if not self.np.verify_header_present():
            errors.append(self.header_error_message)
        if not self.np.verify_footer_present():
            errors.append(self.footer_error_message)
        self.driver.close()

        assert not errors, "errors occured:{}".format("\n".join(errors))

    def test_click_women_evening_dresses(self, setup):
        """ Test to validate by clicking Evening Dresses sub-tab under Women tab to verify the
        header (searchbox), footer (newsletterbox) and page title.

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        errors=[]
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(10)
        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_women_evening_dresses(self.driver)
        if act_title != "Evening Dresses - My Store":
            errors.append(self.title_error_message)
        if not self.np.verify_header_present():
            errors.append(self.header_error_message)
        if not self.np.verify_footer_present():
            errors.append(self.footer_error_message)
        self.driver.close()

        assert not errors, "errors occured:{}".format("\n".join(errors))

    def test_click_women_summer_dresses(self, setup):
        """ Test to validate by clicking Summer Dresses sub-tab under Women tab to verify the
        header (searchbox), footer (newsletterbox) and page title.

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        errors=[]
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(10)
        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_women_summer_dresses(self.driver)
        if act_title != "Summer Dresses - My Store":
            errors.append(self.title_error_message)
        if not self.np.verify_header_present():
            errors.append(self.header_error_message)
        if not self.np.verify_footer_present():
            errors.append(self.footer_error_message)
        self.driver.close()

        assert not errors, "errors occured:{}".format("\n".join(errors))

    def test_click_dresses_casual_dresses(self,setup):
        """ Test to validate by clicking Casual Dresses sub-tab under Dresses tab to verify the
        header (searchbox), footer (newsletterbox) and page title.

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        errors=[]
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(10)
        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_dresses_casual_dresses(self.driver)
        if act_title != "Casual Dresses - My Store":
            errors.append(self.title_error_message)
        if not self.np.verify_header_present():
            errors.append(self.header_error_message)
        if not self.np.verify_footer_present():
            errors.append(self.footer_error_message)
        self.driver.close()

        assert not errors, "errors occured:{}".format("\n".join(errors))

    def test_click_evening_dresses(self,setup):
        """ Test to validate by clicking Evening Dresses sub-tab under Dresses tab to verify the
        header (searchbox), footer (newsletterbox) and page title.

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        errors = []
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(10)
        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_dresses_evening_dresses(self.driver)
        if act_title != "Evening Dresses - My Store":
            errors.append(self.title_error_message)
        if not self.np.verify_header_present():
            errors.append(self.header_error_message)
        if not self.np.verify_footer_present():
            errors.append(self.footer_error_message)
        self.driver.close()

        assert not errors, "errors occured:{}".format("\n".join(errors))

    def test_click_summer_dresses(self,setup):
        """ Test to validate by clicking Summer Dresses sub-tab under Dresses tab to verify the
        header (searchbox), footer (newsletterbox) and page title.

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        errors = []
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(10)
        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_dresses_summer_dresses(self.driver)
        if act_title != "Summer Dresses - My Store":
            errors.append(self.title_error_message)
        if not self.np.verify_header_present():
            errors.append(self.header_error_message)
        if not self.np.verify_footer_present():
            errors.append(self.footer_error_message)
        self.driver.close()

        assert not errors, "errors occured:{}".format("\n".join(errors))

    def test_click_tshirts_tab(self,setup):
        """ Test to validate by clicking Tshirts tab to verify the header (searchbox),
        footer (newsletterbox) and page title.

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        errors=[]
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(10)
        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_tshirts(self.driver)
        if act_title != "T-shirts - My Store":
            errors.append(self.title_error_message)
        if not self.np.verify_header_present():
            errors.append(self.header_error_message)
        if not self.np.verify_footer_present():
            errors.append(self.footer_error_message)
        self.driver.close()

        assert not errors, "errors occured:{}".format("\n".join(errors))

    def test_newsletter_subscription(self, setup):
        """ Test to add the email id in the newsletter texbox .

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        self.driver=setup
        self.driver.get(self.baseURL)
        self.nl = NewsLetterPage(self.driver)
        alert_msg = self.nl.newsletter_subscription(self.email_id)
        errors=[]
        if self.newsletter_success_alert_msg in alert_msg:
            assert True
        else:
            errors.append("This email id is already registered. Please use another email id.")
            assert False

        self.driver.close()

    def test_verify_listing_sorting(self,setup):
        """ Test to verify the results for any one of the filters.we are considering price
        range($16.00 - $32.00).

        :param: setup : This pass the Webdriver from the conftest.py file
        """

        product_price_list=[]
        price_not_in_range_flag=False

        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)
        self.np = NavigateToTabs(self.driver)
        act_title=self.np.click_women_summer_dresses(self.driver)
        self.driver.implicitly_wait(10)
        self.np.list_sorting(self.driver)

        # Using the provided price range value for comparing items price
        prod_range=self.driver.find_element_by_id("layered_price_range").text
        prod_split = prod_range.split("-")
        upper_price_range = float(str(prod_split[0].split("$")[1].strip()))
        lower_price_range = float(str(prod_split[1].split("$")[1].strip()))

        self.driver.implicitly_wait(5)
        prod_price=self.driver.find_elements_by_class_name("price.product-price")

        errors=[]
        # splitting the amount with $ text
        for i in range(len(prod_price)):
            prod_val=prod_price[i].text.split("$")
            product_price_list.append((prod_val))
            self.driver.find_element_by_xpath('//*[@id="search_query_top"]').send_keys(prod_val)

        for i in range(len(product_price_list)):
            if (
                    float(product_price_list[i]) < lower_price_range
                    or
                    float(product_price_list[i]) > upper_price_range
            ):
                price_not_in_range_flag=True
                errors.append("The item is not in range")
                break

        assert not errors, "errors occured:{}".format("\n".join(errors))
