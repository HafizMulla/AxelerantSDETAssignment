""" This file contains all the Methods for subscribing to the newsletter test case """

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class NewsLetterPage():
    """ This class contains the newsletter subscription methods """
    textbox_newsletter_id="newsletter-input"
    button_newsletter_name="submitNewsletter"
    alert_class="alert alert-success"
    alert_text=" Newsletter : You have successfully subscribed to this newsletter."


    def __init__(self,driver):
        self.driver=driver

    def newsletter_subscription(self, emailid):
        """ This method will subscribe to the newsletter using the provided email id

        :param: Email id to subscribe

        :return: The alert message which appear on new page after doing the newsletter
        subscription for success validation

        """
        self.driver.find_element_by_id(self.textbox_newsletter_id).clear()
        self.driver.find_element_by_id(self.textbox_newsletter_id).send_keys(emailid)
        self.driver.find_element_by_name(self.button_newsletter_name).click()
        WebDriverWait(self.driver,10).until(
            EC.presence_of_element_located((By.CLASS_NAME,"clearfix"))
        )

        alert_msg = self.driver.find_element_by_class_name("alert.alert-success").text
        return alert_msg