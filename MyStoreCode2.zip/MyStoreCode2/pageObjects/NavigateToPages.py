""" This file contains all the Methods for navigating to the different tabs
and validating them """

from selenium.webdriver.support.select import Select
from utilities.Utilities import UtilitiesMethods


class NavigateToTabs:
    """ This class contains all the Methods for navigating to the different tabs
    and validating them """

    maintab_css_selector = {
        "women_tshirts": ".sf-menu > li:nth-child(1) > a:nth-child(1)",
        "women_blouses": ".sf-menu > li:nth-child(1) > a:nth-child(1)",
        "women_casual_dresses": ".sf-menu > li:nth-child(1) > a:nth-child(1)",
        "women_evening_dresses": ".sf-menu > li:nth-child(1) > a:nth-child(1)",
        "women_summer_dresses": ".sf-menu > li:nth-child(1) > a:nth-child(1)",
        "dresses_casual_dresses": ".sf-menu > li:nth-child(2) > a:nth-child(1)",
        "dresses_evening_dresses": ".sf-menu > li:nth-child(2) > a:nth-child(1)",
        "dresses_summer_dresses": ".sf-menu > li:nth-child(2) > a:nth-child(1)",
        "tshirts": ".sf-menu > li:nth-child(3) > a:nth-child(1)"
    }

    subtab_title_text = {
        "women_tshirts": "T-shirts - My Store",
        "women_blouses": "Blouses - My Store",
        "women_casual_dresses": "Casual Dresses - My Store",
        "women_evening_dresses": "Evening Dresses - My Store",
        "women_summer_dresses": "Summer Dresses - My Store",
        "dresses_casual_dresses": "Casual Dresses - My Store",
        "dresses_evening_dresses": "Evening Dresses - My Store",
        "dresses_summer_dresses": "Summer Dresses - My Store",
        "tshirts": "T-shirts - My Store"
    }

    subtab_xpath = {
        "women_tshirts": "/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[1]/ul/li[" \
                        "1]/ul/li[1]/a",
        "women_blouses": "/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[1]/ul/li[1]/ul/li["
                   "2]/a",
        "women_casual_dresses": "/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[1]/ul/li["
                          "2]/ul/li[1]/a",
        "women_evening_dresses": "/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[1]/ul/li["
                           "2]/ul/li[2]/a",
        "women_summer_dresses": "/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[1]/ul/li["
                          "2]/ul/li[3]/a",
        "dresses_casual_dresses": "/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li["
                                  "2]/ul/li[1]/a",
        "dresses_evening_dresses": "/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li["
                                   "2]/ul/li[2]/a",
        "dresses_summer_dresses": "/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li["
                                  "2]/ul/li[3]/a",
        "tshirts": "/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[3]/a"
    }

    textbox_searchbox_id="search_query_top"
    textbox_searchbox_xpath='//*[@id="search_query_top"]'
    textbox_newsletter_id="newsletter-input"


    def __init__(self,driver):
        """ To launch the browser """
        self.driver=driver

    def verify_header_present(self):
        """ To verify the header by checking if searchbox is present or not

        :return:It return boolean value (true/false) based on the searchbox is appearing on
        the header part

        """
        return self.driver.find_element_by_id(self.textbox_searchbox_id).is_displayed()

    def verify_footer_present(self):
        """ To verify the footer by checking if newsletter box is present or not

        :return:It return boolean value (true/false) based on the newsletter box is appearing on
        the footer part

        """
        return self.driver.find_element_by_id(self.textbox_newsletter_id).is_displayed()

    def click_women_tshirts(self, driver):
        """" This method will click on the Tshirt subtab under Women tab using xpath and
        css_selector will return the title of the page for verification

        :param: Chrome Driver to launch

        """
        return UtilitiesMethods.verifyTab(
            self.driver,
            self.maintab_css_selector["women_tshirts"],
            self.subtab_xpath ["women_tshirts"],
            self.subtab_title_text["women_tshirts"]
        )

    def click_women_blouses(self, driver):
        """" This method will click on the Blouses subtab under Women tab using xpath and
        css_selector will return the title of the page for verification

        :param: Chrome Driver to launch

        :return: It returns the page tile after navigating to the desired sub tab

        """
        return UtilitiesMethods.verifyTab(
            self.driver,
            self.maintab_css_selector["women_blouses"],
            self.subtab_xpath ["women_blouses"],
            self.subtab_title_text["women_blouses"]
        )

    def click_women_casual_dresses(self, driver):
        """" This method will click on the Casual Dresses subtab under Women tab using
        xpath and css_selector will return the title of the page for verification

        :param: Chrome Driver to launch

        :return: It returns the page tile after navigating to the desired sub tab

        """
        return UtilitiesMethods.verifyTab(
            self.driver,
            self.maintab_css_selector["women_casual_dresses"],
            self.subtab_xpath ["women_casual_dresses"],
            self.subtab_title_text["women_casual_dresses"]
        )

    def click_women_evening_dresses(self, driver):
        """" This method will click on the Evening Dresses subtab under Women tab using
        xpath and css_selector will return the title of the page for verification

        :param: Chrome Driver to launch

        :return: It returns the page tile after navigating to the desired sub tab

        """
        return UtilitiesMethods.verifyTab(
            self.driver,
            self.maintab_css_selector["women_evening_dresses"],
            self.subtab_xpath ["women_evening_dresses"],
            self.subtab_title_text["women_evening_dresses"]
        )

    def click_women_summer_dresses(self, driver):
        """" This method will click on the Evening Dresses subtab under Women tab using
        xpath and css_selector will return the title of the page for verification

        :param: Chrome Driver to launch

        :return: It returns the page tile after navigating to the desired sub tab

        """
        return UtilitiesMethods.verifyTab(
            self.driver,
            self.maintab_css_selector["women_summer_dresses"],
            self.subtab_xpath ["women_summer_dresses"],
            self.subtab_title_text["women_summer_dresses"]
        )

    def click_dresses_casual_dresses(self, driver):
        """" This method will click on the Casual Dresses subtab under Dresses tab using
        xpath and css_selector will return the title of the page for verification

        :param: Chrome Driver to launch

        :return: It returns the page tile after navigating to the desired sub tab

        """
        return UtilitiesMethods.verifyTab(
            self.driver,
            self.maintab_css_selector["dresses_casual_dresses"],
            self.subtab_xpath ["dresses_casual_dresses"],
            self.subtab_title_text["dresses_casual_dresses"]
        )

    def click_dresses_evening_dresses(self, driver):
        """" This method will click on the Evening Dresses subtab under Dresses tab using
        xpath and css_selector will return the title of the page for verification

        :param: Chrome Driver to launch

        :return: It returns the page tile after navigating to the desired sub tab

        """
        return UtilitiesMethods.verifyTab(
            self.driver,
            self.maintab_css_selector["dresses_evening_dresses"],
            self.subtab_xpath ["dresses_evening_dresses"],
            self.subtab_title_text["dresses_evening_dresses"]
        )

    def click_dresses_summer_dresses(self, driver):
        """" This method will click on the Summer Dresses sub-tab under Dresses tab using
        xpath and css_selector will return the title of the page for verification

        :param: Chrome Driver to launch

        :return: It returns the page tile after navigating to the desired sub tab

        """
        return UtilitiesMethods.verifyTab(
            self.driver,
            self.maintab_css_selector["dresses_summer_dresses"],
            self.subtab_xpath ["dresses_summer_dresses"],
            self.subtab_title_text["dresses_summer_dresses"]
        )

    def click_tshirts(self, driver):
        """" This method will click on the Tshirts tab using xpath and css_selector
        will return the title of the page for verification

        :param: Chrome Driver to launch

        :return: It returns the page tile after navigating to the desired sub tab

        """
        return UtilitiesMethods.verifyTab(
            self.driver,
            self.maintab_css_selector["tshirts"],
            self.subtab_xpath ["tshirts"],
            self.subtab_title_text["tshirts"]
        )

    def list_sorting(self, driver):
        """" This method will select the "Reference: Highest First" in the dropdown menu

        :param: Chrome Driver to launch

        """
        dropdown = Select(driver.find_element_by_id("selectProductSort"))
        dropdown.select_by_visible_text("Reference: Highest first")
