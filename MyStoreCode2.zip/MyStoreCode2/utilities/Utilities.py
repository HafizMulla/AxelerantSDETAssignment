""" This file contain the common methods used in the test cases """

from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class UtilitiesMethods:

    @staticmethod
    def verifyTab(driver, link_css_selector, link_xpath, link_title_text):
        """ This is a static method used to navigate to the sub tabs under main tab (like
        nvaigating to the subtab tshirts under main tab:Women tab).

        :param driver: The webdriver use to launch the browser
        :param link_css_selector: The css_selector of the main tab to navigate
        :param link_xpath: The xpath of the sub tab to navigate
        :param link_title_text: The page title use for validating of the page

        :return: The title of the page after navigating to the subtab

        """
        action = ActionChains(driver)
        menu = driver.find_element_by_css_selector(link_css_selector)
        action.move_to_element(menu).perform()

        submenu=driver.find_element_by_xpath(link_xpath)
        action.move_to_element(submenu).click().perform()

        WebDriverWait(driver,10).until(EC.title_contains(link_title_text))
        act_title=driver.title

        return act_title
